# Tiva Home Android app

Android controller for the Tiva C home-automation firmware using an HC-05 Bluetooth Classic module (SPP/RFCOMM).

## Firmware protocol used

The app follows the commands in the supplied `home-automation/application.c` exactly:

| App action | Bytes sent to Tiva |
|---|---|
| Refresh status | `STATUS\r\n` |
| Lamp ON | `LAMP_ON\r\n` |
| Lamp OFF | `LAMP_OFF\r\n` |
| Socket ON | `PLUG_ON\r\n` |
| Socket OFF | `PLUG_OFF\r\n` |

The app parses the firmware response fields:
`LAMP=ON/OFF`, `PLUG=ON/OFF`, `DOOR=OPEN/CLOSED`, and `TEMP=<value>`.

## Bluetooth settings

- Bluetooth type: Bluetooth Classic (not BLE)
- Profile: Serial Port Profile (SPP / RFCOMM)
- UUID: `00001101-0000-1000-8000-00805F9B34FB`
- UART: 9600 baud, 8 data bits, no parity, 1 stop bit
- Firmware UART: UART1 on PB0 (RX) and PB1 (TX)

## Hardware wiring reminder

- HC-05 TXD -> Tiva PB0 / U1RX
- HC-05 RXD <- Tiva PB1 / U1TX (use a 3.3 V logic-level signal)
- HC-05 GND -> Tiva GND
- HC-05 VCC -> the voltage supported by your HC-05 breakout board (many breakout boards accept 5 V on VCC, but the RX logic input is still 3.3 V)

## First-time setup on the Android phone

1. Power the Tiva board and HC-05.
2. Open Android Settings -> Bluetooth / Connected devices.
3. Pair with `HC-05` (or the Bluetooth name configured on your module).
4. If asked for a PIN, use the PIN configured on your module. Common factory defaults are `1234` or `0000`; not every module uses the same PIN.
5. Open **Tiva Home**.
6. Grant the **Nearby devices** permission when Android asks.
7. Select the paired HC-05 from the list and tap **Connect**.
8. The app automatically requests `STATUS` after connecting.
9. Use the Lamp and Socket buttons. The app requests a fresh status after each command.

The app only lists already-paired Bluetooth devices; it does not perform a Bluetooth scan. This avoids requesting scan or location permission and keeps setup straightforward.

## Build the APK in Android Studio

This environment does not include the Android SDK, Android Gradle Plugin cache, or Gradle, and outbound access to Google's SDK repositories is unavailable. Therefore an APK cannot be compiled in this session. The Android Studio project is provided complete and has no third-party library dependencies.

1. Install Android Studio (current stable) on Windows/macOS/Linux.
2. Install Android SDK Platform 35 and Android SDK Build-Tools using SDK Manager.
3. Open this `TivaHome_Android` folder in Android Studio.
4. Allow Gradle sync to download the Android Gradle Plugin and Gradle distribution.
5. Select **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
6. Android Studio creates the debug APK at:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Copy that APK to your phone and install it. If Android asks, allow installation from that file manager/browser.

For a release APK: **Build -> Generate Signed Bundle / APK -> APK**, create or select a keystore, then complete the wizard.

## Notes

- Minimum Android version: Android 6.0 (API 23).
- Target SDK: API 34.
- App package: `com.tivahome.automation`.
- The app does not control mains voltage directly; it sends commands to the Tiva firmware. Test relay logic with mains disconnected first.
