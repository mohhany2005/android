# Tiva Home Android — v2.0

This version keeps the previous app's Bluetooth Classic RFCOMM/SPP connection method and serial command/ACK workflow, but updates the command strings and response parser to match the **working firmware supplied in `HomeAutomation_IAR.zip`**.

## Important protocol compatibility note

The old app sent `STATUS`, `LAMP_ON`, `LAMP_OFF`, `PLUG_ON`, and `PLUG_OFF`. Those commands are not accepted by the supplied current firmware. The app now sends the exact firmware protocol:

| Action | Command sent (LF terminated) | Exact acknowledgement |
|---|---|---|
| Lamp ON | `LAMP:1` | `ACK:LAMP:1` |
| Lamp OFF | `LAMP:0` | `ACK:LAMP:0` |
| Plug ON | `PLUG:1` | `ACK:PLUG:1` |
| Plug OFF | `PLUG:0` | `ACK:PLUG:0` |
| Apply limit | `LIMIT:<signed whole number>` | `ACK:LIMIT:<same value>` |
| Refresh | `STATUS?` | `ACK:STATUS?` then five ordered state lines |

Commands are sent as ASCII followed by LF (`0x0A`). The app accepts the board's CRLF responses and buffers fragmented or coalesced Bluetooth receive chunks until a complete LF-terminated line is available.

## Features implemented from the project specification

- HC-05 Bluetooth Classic RFCOMM/SPP; paired-device list, connection state, disconnect/reconnect.
- Known HC-05 address `00:24:08:00:53:9D` is sorted first. Pair in Android Bluetooth settings; enter PIN `1234` if prompted.
- Lamp and plug controls wait for the exact matching ACK and then request a status snapshot.
- Dashboard shows confirmed lamp, plug, door, temperature, and alarm state.
- On connection, the saved temperature limit (default 30 °C) is sent and its exact ACK is awaited before `STATUS?`.
- Temperature is updated from unsolicited `TEMP:` messages from the board; the app does not poll `STATUS?` every second.
- Temperature is marked stale after 3 seconds without a valid sample.
- `TEMP:ERR` is shown as a sensor fault and does not clear the current alarm state.
- A single persistent alarm banner reflects `ALARM:1` / `ALARM:0`; repeated temperature samples do not create modal dialogs.
- Whole-number signed temperature limit validation uses the firmware's signed 32-bit range.
- Door history saves only standalone live `DOOR:OPEN` / `DOOR:CLOSED` events using the phone's receive-time clock. The history persists after app restart and displays newest first.
- The `DOOR:` line inside a `STATUS?` snapshot is never added to history.
- Connection gaps are stored and shown as intervals where door changes are unknown; the app does not invent door events during gaps.
- Snapshot is applied only after all five fields arrive in exact order: `LAMP`, `PLUG`, `DOOR`, `TEMP`, `ALARM`.
- Handles partial/multiple receive chunks, invalid ASCII bytes (hex diagnostic log), overlong lines, device errors, missing ACKs, malformed snapshots, and disconnects.
- One command is in flight at a time. A successful Bluetooth write alone is not treated as command confirmation.

## Snapshot response expected from the supplied firmware

```text
ACK:STATUS?
LAMP:0
PLUG:0
DOOR:CLOSED
TEMP:25.8
ALARM:0
```

The board also sends `TEMP:` every second, `DOOR:` on a door transition, and `ALARM:` when alarm state changes.

## Build APK using the existing GitHub Actions workflow

1. Upload this archive to the root of the existing repository, replacing the old `TivaHome_Android_Project.zip`.
2. Keep the existing `.github/workflows/build-apk.yml` workflow unchanged.
3. Open GitHub **Actions** → **Build Tiva Home APK** → **Run workflow**.
4. When the run succeeds, download artifact `TivaHome-debug-apk` and extract `app-debug.apk`.
5. Install it on the phone. If Android reports a signature conflict with the previous debug APK, uninstall the old debug app first.

The application ID remains `com.tivahome.automation`; `versionCode` is now 2 and `versionName` is 2.0. A fresh GitHub runner may generate a different debug keystore, so uninstalling the previous debug build may be required.

## Hardware assumptions — unchanged

- TM4C123GH6PM LaunchPad and HC-05.
- HC-05 TXD → PB0 / UART1 RX.
- HC-05 RXD ← PB1 / UART1 TX.
- HC-05/external supply GND → LaunchPad GND (shared ground is essential).
- UART1: 9600 baud, 8 data bits, no parity, 1 stop bit.
- This Android update does not change any Tiva pin assignments.

## Local test notes

`ProtocolEngine.java` was compiled with `javac` and exercised with a simulated board stream. Tests passed for LF command framing, exact ACK matching, split and coalesced receive data, ordered five-line status snapshots, unsolicited temperature and door events, relay ACK followed by a fresh snapshot, and malformed-snapshot recovery. The Android Activity source was syntax-checked; a full Android Gradle build must be run by GitHub Actions because this environment does not contain the Android SDK.
