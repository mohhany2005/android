# Mobile application specification - Fall 2026 home automation

Source: `C:\Users\Asus\Downloads\Fall 26_project.pdf`, pages 1-3.
Page 2 defines the wire protocol; page 1 defines the app features.
Prepared on 2026-11-25 for the firmware in this workspace.

## Scope and current status

Integrate the existing phone app with the TM4C123GH6PM through the HC-05.
The existing app source was not supplied, so the checklist below identifies
features to **check or add**, rather than claiming they are absent from that app.

The firmware now implements the PDF commands, command acknowledgements, one-second
temperature updates, door-change events, and temperature alarms. It uses a default
limit of **30 degrees C**, as selected by the user. The firmware and updated desktop
test client have been tested on the connected board. A mobile implementation is
still required for the course submission; the desktop client is a diagnostic tool.

## Required app features to check or add

| ID | Feature | Required behavior / acceptance criterion |
|---|---|---|
| APP-01 | Bluetooth connection | Connect to the HC-05, display connection state, and allow disconnect/reconnect. Pair using PIN 1234 when required. |
| APP-02 | Lamp control | Send `LAMP:1` / `LAMP:0`; show the confirmed state after matching ACK and status. |
| APP-03 | Plug control | Send `PLUG:1` / `PLUG:0`; show the confirmed state after matching ACK and status. |
| APP-04 | Door display | Show OPEN/CLOSED from status and every live `DOOR:` event. |
| APP-05 | Live room temperature | Display `TEMP:` values in degrees C; the board sends an update every second. |
| APP-06 | Temperature limit and alert | Accept a whole-number limit, send `LIMIT:`, wait for its ACK, and display a visible alert for `ALARM:1`; clear it for `ALARM:0`. |
| APP-07 | Persistent door history | Save each live opening/closing event with the phone's receive-time clock; show the saved list and retain it after restarting the app. |

All seven are required by the project. Check the existing app against this table
and implement any missing rows. The stream parsing and recovery rules below are
integration requirements needed to make those features work reliably.

## Hardware and transport contract

- Board: TM4C123GH6PM LaunchPad; module: HC-05, Bluetooth Classic serial connection.
- Known module address: `00:24:08:00:53:9D`; pairing PIN: `1234`.
- Use Bluetooth Classic serial/RFCOMM, rather than a BLE/GATT connection.
- The working desktop test uses RFCOMM channel 1. A phone app should locate the
  module's serial service using its Bluetooth serial component/library.
- HC-05 physical UART: **9600 baud, 8 data bits, no parity, 1 stop bit**.
- HC-05 TXD -> PB0; HC-05 RXD -> PB1; HC-05/external-supply GND -> LaunchPad GND.
  Shared ground is essential: its absence caused the earlier corrupted bytes.
- The LaunchPad DEBUG virtual COM port is UART0 and is separate from this UART1 link.

## Line protocol

All messages are case-sensitive ASCII text. Send a newline (`LF`, byte `0A`) after
each command. The board transmits `CRLF`; remove the optional CR before parsing
each received LF-terminated line. CR-only input is also accepted for terminal use.
Bluetooth receive callbacks may contain half a line, several lines, or even only
one byte. Keep an input buffer and process complete lines in order.

### Commands sent by the app

| Command | Matching acknowledgement | Effect |
|---|---|---|
| `LAMP:1` | `ACK:LAMP:1` | Set PA2 lamp relay ON. |
| `LAMP:0` | `ACK:LAMP:0` | Set PA2 lamp relay OFF. |
| `PLUG:1` | `ACK:PLUG:1` | Set PA3 plug relay ON. |
| `PLUG:0` | `ACK:PLUG:0` | Set PA3 plug relay OFF. |
| `LIMIT:30` | `ACK:LIMIT:30` | Set the alarm threshold to 30 degrees C. |
| `STATUS?` | `ACK:STATUS?`, then the snapshot below | Read all five states. |

`LIMIT:` accepts a signed whole number. The firmware's representable range is
`-2147483648` through `2147483647`; decimals, missing digits, extra characters,
and overflow are rejected. The ACK repeats the received command exactly,
including any explicit sign or leading zeros. The app can send canonical decimal
integers without leading zeros. The maximum input is 31 ASCII bytes before newline.

The startup limit is 30 degrees C. `LIMIT:` changes it immediately in RAM;
resetting or powering down the MCU restores 30. Store the user's preferred limit
in the app and reapply it after connecting. If the MCU is reset independently
while the HC-05 stays connected, reconnect/resynchronize before relying on the
app's previously selected limit.

The old `STATUS`, `LAMP_ON`, `LAMP_OFF`, `PLUG_ON`, and `PLUG_OFF` commands are
replaced by the PDF commands. Do not send the pairing PIN as an application command.

### STATUS? reply

The course PDF lists the five required states but does not prescribe a combined
reply layout. This implementation returns the following **ordered, contiguous**
bundle, using colon-style fields:

```text
ACK:STATUS?
LAMP:0
PLUG:0
DOOR:CLOSED
TEMP:25.8
ALARM:0
```

After `ACK:STATUS?`, consume exactly five state lines in the order LAMP, PLUG,
DOOR, TEMP, ALARM. These lines form one snapshot. Periodic events are not inserted
inside the bundle. Validate the order before applying the complete snapshot.
`LAMP:` and `PLUG:` carry 0 or 1; door is OPEN or CLOSED; temperature has one
decimal place; alarm is 0 or 1. There is no `C` suffix on the wire; show the unit
in the UI. The snapshot reports relay command state, not measured mains current.

**Do not create a door-history entry from the snapshot's DOOR line.** Repeated
status requests must not fill the history with fake openings or closings. An
incomplete or malformed snapshot must be discarded, with a fresh `STATUS?`
requested after resynchronizing; do not reinterpret its remaining DOOR field as
a live event. `ACK:STATUS?` marks the beginning of a new snapshot.

### Unsolicited messages sent by the board

| Message | Meaning | App action |
|---|---|---|
| `TEMP:27.5` | Latest temperature, emitted every second. | Update displayed temperature and freshness time. |
| `DOOR:OPEN` | Door changed to open. | Update display; save a phone-timestamped opening event. |
| `DOOR:CLOSED` | Door changed to closed. | Update display; save a phone-timestamped closing event. |
| `ALARM:1` | Temperature is above the current limit. | Show the active temperature alert. |
| `ALARM:0` | Temperature is at or below the current limit. | Clear the active alert. |

ALARM events are sent when the state changes; a STATUS? snapshot also reports
the current alarm state. `LIMIT:` can cause an immediate ALARM event. The comparison
is strict: at a 30-degree limit, 30.0 is not an alarm and 30.1 is an alarm.
Receiving repeated temperature samples while alarmed must not open a new modal
dialog every second. Maintain an alarm state and update one persistent alert.

### Explicit fault extensions

The PDF does not define malformed-command or sensor-failure messages. These
extensions prevent silent failure and must be handled by the app:

| Message | App behavior |
|---|---|
| `TEMP:ERR` | Mark the temperature unavailable; do not display 0 degrees or silently clear an alert. |
| `ERR:COMMAND` | Show/recover from an unsupported command; no matching ACK will follow. |
| `ERR:LIMIT` | Keep the previous confirmed limit and show invalid-limit feedback. |
| `ERR:LINE_TOO_LONG` | Treat the command as failed; send a shorter complete command. |
| `ERR:UART` | Treat the command as failed; report a communication problem and resynchronize. |

On ADC failure the board retains its last alarm state until a valid sample is
available. The app should distinguish a temperature sensor fault from an ordinary
non-alarm condition. Bytes that are not valid ASCII protocol data must be retained
in diagnostic logs, rather than silently discarded or treated as a valid response.

## Suggested screens

1. **Connection:** selected HC-05, connect/disconnect, connection status, errors.
2. **Dashboard:** lamp and plug controls; door OPEN/CLOSED; latest temperature;
   whole-number limit editor with Apply; active temperature alert; Refresh Status.
3. **Door history:** newest-first events with OPEN/CLOSED and local date/time.
   Read the history from persistent storage after an app restart.

The controls represent relay states. In the required hardware arrangement, the
lamp's manual switch is parallel to the relay, so the manual switch can keep the
lamp lit even when the lamp relay is OFF. The app cannot infer actual lamp power
from the relay bit alone.

## Connection and command flow

1. Establish the HC-05 serial connection and begin buffering incoming bytes.
2. Send `LIMIT:<saved preference>`, or `LIMIT:30` when no preference exists.
3. Wait for its matching ACK; continue processing asynchronous TEMP/DOOR/ALARM lines.
4. Send `STATUS?` and apply the complete five-state snapshot.
5. Show the connected dashboard and consume the board's periodic/events stream.
6. For a relay button, send one command, await its exact ACK, then refresh status.
7. On disconnect, disable controls, show values as stale, and preserve door history.
   Repeat initialization after reconnecting; do not automatically replay old relay
   commands that might have failed before the disconnect.

Keep one command in flight at a time. A command is confirmed by its matching
ACK, not by a successful Bluetooth write. As an app-side policy, use a two-second
ACK/snapshot timeout and mark temperature stale after three seconds without a
valid sample. These timeout values are implementation choices, not extra course
requirements. A timeout should offer retry/reconnect without claiming success.

## Door-event storage

For each standalone DOOR event, store:

| Field | Purpose |
|---|---|
| Local record ID / sequence | Stable identity and arrival order, even if the phone clock changes. |
| State | OPEN or CLOSED. |
| Receive timestamp | Phone clock time at receipt, saved as UTC with local offset/timezone context. |
| Device address | Associate the event with the connected HC-05. |

Show timestamps in the phone's local timezone. Save on receipt, not when the
history screen is opened. The board does not provide event timestamps or buffer
offline door events: history covers events actually received while connected.
Indicate connection gaps instead of inventing opening/closing times for them.
The desktop client's optional door log uses the PC clock for diagnostics; the
submitted phone app must use the phone clock as the PDF requires.

## Acceptance tests for the existing app

- [ ] Connect/pair with the HC-05 and show disconnected/connected states correctly.
- [ ] Each lamp/plug button sends the exact PDF command and waits for matching ACK.
- [ ] STATUS? populates all five dashboard states without generating history entries.
- [ ] Split a response across receive callbacks and combine multiple responses in one
  callback; both cases parse correctly.
- [ ] Display a new temperature about every second without polling STATUS? every second.
- [ ] Apply a whole-number limit; demonstrate ALARM:1 above it and ALARM:0 at/below it.
- [ ] Show only one persistent active alert during repeated high-temperature readings.
- [ ] Record real door opening and closing events using the phone clock; reopen the
  app and verify the list persists.
- [ ] Handle invalid limits, TEMP:ERR, malformed messages, missing ACKs, and disconnects.
- [ ] Reconnect and resynchronize states/limit while retaining saved door history.

## Firmware validation and remaining work

The installed IAR compiler/assembler/linker built the new firmware without errors
or warnings. All 3,286 application bytes matched the independent ICDI flash
readback. A live HC-05 session passed six command acknowledgements, three complete
snapshots, seven periodic TEMP messages, and both alarm transitions. Observed TEMP
receive intervals were 1.000-1.031 seconds. The test restored `LIMIT:30` and left
the firmware running. Evidence: `build/pdf-protocol-live.jsonl` and
`build/pdf-protocol-flash-check.txt`.

A subsequent final-client test sent two STATUS? queries one byte at a time;
both snapshots and ACKs passed while three periodic temperature updates arrived.
Evidence: `build/pdf-protocol-fragmented.jsonl`. The normal build under
`build/iar/` contains the same application binary as the verified PDF-protocol build.

Host tests cover relay command handling, exact ACKs, snapshots, one-second timing,
threshold equality, signed limits and overflow, door events, ADC/UART errors, long
line recovery, timer rollover, and client stream parsing. Relay energization and
new physical door transitions were not exercised in this live protocol test.

Remaining integration work is to audit the existing app with the checklist and
implement its missing items. Course deliverables also require the app project
source, a five-minute demonstration, and a technical PDF report covering team
contributions, program flowcharts, components/wiring, prototype photos, and problems
and solutions, packaged with the firmware by the end of Week 13. Those submission
artifacts are separate from this application integration specification.
