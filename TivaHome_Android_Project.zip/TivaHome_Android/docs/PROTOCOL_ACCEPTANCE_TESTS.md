# Protocol acceptance tests

Test with the firmware in the uploaded `HomeAutomation_IAR.zip` archive.

1. Pair HC-05 in Android Bluetooth Settings. Use PIN `1234` if prompted.
2. Connect from the app's Connection screen.
3. Verify `TX LIMIT:30`, `RX ACK:LIMIT:30`, then `TX STATUS?`.
4. Verify `ACK:STATUS?` followed by exactly `LAMP`, `PLUG`, `DOOR`, `TEMP`, `ALARM` in that order.
5. Verify the temperature updates about once per second without repeated `STATUS?` commands.
6. Change the door input; verify one timestamped event appears in Door history.
7. Request status several times; verify snapshot `DOOR:` lines do not create history entries.
8. Apply a whole-number temperature limit; verify the exact `ACK:LIMIT:<value>`.
9. Test `ALARM:1` above the limit and `ALARM:0` at or below the limit.
10. Test `TEMP:ERR`; verify the sensor fault appears and the alarm state is not silently cleared.
11. Test malformed input, missing ACK, and Bluetooth disconnect/reconnect.
12. Close and reopen the app; verify the saved limit and door history persist.
13. Verify connection gaps are displayed as unknown intervals, not invented door events.
