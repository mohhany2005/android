plugins { id("com.android.application") }

android {
    namespace = "com.tivahome.automation"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tivahome.automation"
        minSdk = 23
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
