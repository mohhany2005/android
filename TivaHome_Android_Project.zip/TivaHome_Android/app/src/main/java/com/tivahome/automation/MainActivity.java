package com.tivahome.automation;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int REQ_BT_CONNECT = 410;
    private static final int REQ_ENABLE_BT = 411;
    private static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private static final int BG = Color.rgb(16, 24, 39);
    private static final int CARD = Color.rgb(27, 39, 58);
    private static final int CARD_ALT = Color.rgb(34, 48, 69);
    private static final int TEXT = Color.rgb(240, 245, 250);
    private static final int MUTED = Color.rgb(157, 174, 193);
    private static final int TEAL = Color.rgb(25, 183, 165);
    private static final int RED = Color.rgb(239, 91, 91);
    private static final int AMBER = Color.rgb(244, 184, 75);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService ioExecutor = Executors.newCachedThreadPool();
    /* Only one command/status transaction may run at a time. */
    private final ExecutorService commandExecutor = Executors.newSingleThreadExecutor();
    private final BlockingQueue<String> receivedLines = new LinkedBlockingQueue<>(32);
    private final AtomicBoolean commandBusy = new AtomicBoolean(false);
    private final Object outputLock = new Object();

    private BluetoothAdapter bluetoothAdapter;
    private volatile BluetoothSocket socket;
    private volatile InputStream input;
    private volatile OutputStream output;
    private volatile boolean connected = false;

    private Spinner deviceSpinner;
    private Button connectButton;
    private Button refreshDevicesButton;
    private Button statusButton;
    private TextView connectionText;
    private TextView temperatureText;
    private TextView doorText;
    private TextView lampStateText;
    private TextView plugStateText;
    private TextView logText;
    private Button lampOnButton, lampOffButton, plugOnButton, plugOffButton;
    private final List<BluetoothDevice> pairedDevices = new ArrayList<>();
    private final List<String> logLines = new ArrayList<>();

    private String lampState = "UNKNOWN";
    private String plugState = "UNKNOWN";
    private String doorState = "UNKNOWN";
    private String temperature = "--.- °C";

    private static final Pattern LAMP_PATTERN = Pattern.compile("(?:^|\\s)LAMP=(ON|OFF)(?:\\s|$)");
    private static final Pattern PLUG_PATTERN = Pattern.compile("(?:^|\\s)PLUG=(ON|OFF)(?:\\s|$)");
    private static final Pattern DOOR_PATTERN = Pattern.compile("(?:^|\\s)DOOR=(OPEN|CLOSED)(?:\\s|$)");
    private static final Pattern TEMP_PATTERN = Pattern.compile("(?:^|\\s)TEMP=([0-9]+(?:\\.[0-9]+)?)");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        buildInterface();
        updateAllViews();
        checkBluetoothPermissionAndLoad();
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(20), dp(20), dp(28));
        scroll.addView(page);

        TextView eyebrow = text("SMART HOME • TIVA C SERIES", 11, TEAL, true);
        eyebrow.setLetterSpacing(0.12f);
        page.addView(eyebrow, margin(WRAP, WRAP, 0, 0, 0, 8));

        TextView title = text("Tiva Home", 30, TEXT, true);
        page.addView(title, margin(WRAP, WRAP, 0, 0, 0, 4));

        TextView subtitle = text("Bluetooth control panel", 14, MUTED, false);
        page.addView(subtitle, margin(WRAP, WRAP, 0, 0, 0, 20));

        LinearLayout connectionCard = card();
        page.addView(connectionCard, margin(MATCH, WRAP, 0, 0, 0, 14));

        LinearLayout connectionTop = horizontal();
        connectionCard.addView(connectionTop, new LinearLayout.LayoutParams(MATCH, WRAP));
        TextView connectTitle = text("Bluetooth connection", 17, TEXT, true);
        connectionTop.addView(connectTitle, new LinearLayout.LayoutParams(0, WRAP, 1));
        connectionText = text("DISCONNECTED", 11, AMBER, true);
        connectionTop.addView(connectionText);

        TextView pairHint = text("Pair your HC-05 in Android Bluetooth settings first. It should appear below as a paired device.", 12, MUTED, false);
        pairHint.setLineSpacing(dp(2), 1f);
        connectionCard.addView(pairHint, margin(MATCH, WRAP, 0, 10, 0, 12));

        deviceSpinner = new Spinner(this);
        deviceSpinner.setBackground(tintDrawable(CARD_ALT, 12));
        connectionCard.addView(deviceSpinner, margin(MATCH, dp(48), 0, 0, 0, 10));

        LinearLayout connectionButtons = horizontal();
        refreshDevicesButton = button("Refresh", false);
        connectButton = button("Connect", true);
        connectionButtons.addView(refreshDevicesButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams connectLp = new LinearLayout.LayoutParams(0, dp(48), 1);
        connectLp.leftMargin = dp(10);
        connectionButtons.addView(connectButton, connectLp);
        connectionCard.addView(connectionButtons);

        TextView sensorsHeader = sectionTitle("LIVE SENSORS");
        page.addView(sensorsHeader, margin(WRAP, WRAP, 2, 12, 0, 10));

        LinearLayout sensorRow = horizontal();
        page.addView(sensorRow, margin(MATCH, WRAP, 0, 0, 0, 12));
        LinearLayout tempCard = miniCard();
        LinearLayout doorCard = miniCard();
        sensorRow.addView(tempCard, new LinearLayout.LayoutParams(0, dp(112), 1));
        LinearLayout.LayoutParams doorLp = new LinearLayout.LayoutParams(0, dp(112), 1);
        doorLp.leftMargin = dp(12);
        sensorRow.addView(doorCard, doorLp);

        tempCard.addView(text("TEMPERATURE", 10, MUTED, true));
        temperatureText = text(temperature, 25, TEXT, true);
        tempCard.addView(temperatureText, margin(WRAP, WRAP, 0, 12, 0, 0));
        doorCard.addView(text("DOOR SENSOR", 10, MUTED, true));
        doorText = text("Unknown", 20, TEXT, true);
        doorCard.addView(doorText, margin(WRAP, WRAP, 0, 14, 0, 0));

        TextView controlsHeader = sectionTitle("APPLIANCE CONTROL");
        page.addView(controlsHeader, margin(WRAP, WRAP, 2, 12, 0, 10));

        LinearLayout lampCard = applianceCard("Lamp");
        page.addView(lampCard, margin(MATCH, WRAP, 0, 0, 0, 12));
        lampStateText = (TextView) lampCard.getTag();
        LinearLayout lampActions = (LinearLayout) lampCard.getChildAt(2);
        lampOnButton = button("Turn ON", true);
        lampOffButton = button("Turn OFF", false);
        lampActions.addView(lampOnButton, new LinearLayout.LayoutParams(0, dp(44), 1));
        LinearLayout.LayoutParams lampOffLp = new LinearLayout.LayoutParams(0, dp(44), 1);
        lampOffLp.leftMargin = dp(8);
        lampActions.addView(lampOffButton, lampOffLp);

        LinearLayout plugCard = applianceCard("Socket / Plug");
        page.addView(plugCard, margin(MATCH, WRAP, 0, 0, 0, 12));
        plugStateText = (TextView) plugCard.getTag();
        LinearLayout plugActions = (LinearLayout) plugCard.getChildAt(2);
        plugOnButton = button("Turn ON", true);
        plugOffButton = button("Turn OFF", false);
        plugActions.addView(plugOnButton, new LinearLayout.LayoutParams(0, dp(44), 1));
        LinearLayout.LayoutParams plugOffLp = new LinearLayout.LayoutParams(0, dp(44), 1);
        plugOffLp.leftMargin = dp(8);
        plugActions.addView(plugOffButton, plugOffLp);

        statusButton = button("↻   Refresh status", false);
        page.addView(statusButton, margin(MATCH, dp(48), 0, 2, 0, 18));

        TextView logHeader = sectionTitle("DEVICE MESSAGES");
        page.addView(logHeader, margin(WRAP, WRAP, 2, 0, 0, 8));
        LinearLayout logCard = card();
        page.addView(logCard, new LinearLayout.LayoutParams(MATCH, WRAP));
        logText = text("No messages yet.", 12, MUTED, false);
        logText.setTypeface(Typeface.MONOSPACE);
        logText.setLineSpacing(dp(3), 1f);
        logCard.addView(logText);

        TextView footer = text("HC-05  •  UART1  •  9600 baud  •  8-N-1", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        page.addView(footer, margin(MATCH, WRAP, 0, 18, 0, 0));

        setContentView(scroll);

        refreshDevicesButton.setOnClickListener(v -> checkBluetoothPermissionAndLoad());
        connectButton.setOnClickListener(v -> {
            if (connected) disconnectBluetooth("Disconnected by user.");
            else connectSelectedDevice();
        });
        statusButton.setOnClickListener(v -> sendCommand("STATUS"));
        lampOnButton.setOnClickListener(v -> sendCommand("LAMP_ON"));
        lampOffButton.setOnClickListener(v -> sendCommand("LAMP_OFF"));
        plugOnButton.setOnClickListener(v -> sendCommand("PLUG_ON"));
        plugOffButton.setOnClickListener(v -> sendCommand("PLUG_OFF"));
    }

    private LinearLayout applianceCard(String name) {
        LinearLayout box = card();
        LinearLayout top = horizontal();
        box.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));
        TextView label = text(name, 17, TEXT, true);
        top.addView(label, new LinearLayout.LayoutParams(0, WRAP, 1));
        TextView state = text("UNKNOWN", 11, AMBER, true);
        top.addView(state);
        box.setTag(state);
        TextView desc = text("Choose an action", 11, MUTED, false);
        box.addView(desc, margin(MATCH, WRAP, 0, 5, 0, 12));
        LinearLayout actions = horizontal();
        box.addView(actions);
        return box;
    }

    private void checkBluetoothPermissionAndLoad() {
        if (bluetoothAdapter == null) {
            showToast("This phone does not support Bluetooth.");
            addLog("Bluetooth adapter not available.");
            return;
        }
        if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_CONNECT);
            return;
        }
        loadPairedDevices();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_CONNECT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadPairedDevices();
            } else {
                showToast("Bluetooth permission is required to connect to HC-05.");
                addLog("Bluetooth permission denied.");
            }
        }
    }

    private void loadPairedDevices() {
        if (bluetoothAdapter == null) return;
        try {
            Set<BluetoothDevice> bonded = bluetoothAdapter.getBondedDevices();
            pairedDevices.clear();
            if (bonded != null) pairedDevices.addAll(bonded);
            Collections.sort(pairedDevices, (a, b) -> safeName(a).compareToIgnoreCase(safeName(b)));

            List<String> labels = new ArrayList<>();
            if (pairedDevices.isEmpty()) {
                labels.add("No paired devices — pair HC-05 in Settings");
            } else {
                for (BluetoothDevice d : pairedDevices) {
                    labels.add(safeName(d) + "  •  " + d.getAddress());
                }
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, labels);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            deviceSpinner.setAdapter(adapter);
            addLog(pairedDevices.size() + " paired Bluetooth device(s) found.");
            if (!bluetoothAdapter.isEnabled()) {
                showToast("Turn Bluetooth on to connect.");
                startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));
            }
        } catch (SecurityException e) {
            addLog("Bluetooth permission is missing. Allow Nearby devices permission.");
        }
    }

    private String safeName(BluetoothDevice device) {
        try {
            String name = device.getName();
            return name == null || name.trim().isEmpty() ? "Bluetooth device" : name;
        } catch (SecurityException e) {
            return "Bluetooth device";
        }
    }

    private void connectSelectedDevice() {
        if (bluetoothAdapter == null) return;
        if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            checkBluetoothPermissionAndLoad();
            return;
        }
        if (!bluetoothAdapter.isEnabled()) {
            showToast("Please turn Bluetooth on first.");
            startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));
            return;
        }
        int selected = deviceSpinner.getSelectedItemPosition();
        if (selected < 0 || selected >= pairedDevices.size()) {
            showToast("Pair your HC-05 in Android Bluetooth settings first.");
            return;
        }
        BluetoothDevice device = pairedDevices.get(selected);
        setConnecting(true, "CONNECTING…");
        addLog("Connecting to " + safeName(device) + "…");

        ioExecutor.execute(() -> {
            BluetoothSocket candidate = null;
            try {
                // The app only connects to already-paired devices; it does not scan.
                candidate = device.createRfcommSocketToServiceRecord(SPP_UUID);
                candidate.connect();
                socket = candidate;
                input = candidate.getInputStream();
                output = candidate.getOutputStream();
                connected = true;

                mainHandler.post(() -> {
                    setConnecting(false, "CONNECTED");
                    addLog("Connected to " + safeName(device) + ".");
                    showToast("Connected to " + safeName(device));
                });

                receivedLines.clear();
                startReader(candidate);
                mainHandler.post(() -> sendCommand("STATUS"));
            } catch (Exception e) {
                closeQuietly(candidate);
                if (socket == candidate) {
                    socket = null;
                    input = null;
                    output = null;
                }
                connected = false;
                String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                mainHandler.post(() -> {
                    setConnecting(false, "DISCONNECTED");
                    addLog("Connection failed: " + message);
                    showToast("Could not connect. Check HC-05 pairing and power.");
                });
            }
        });
    }

    private void startReader(BluetoothSocket activeSocket) {
        ioExecutor.execute(() -> {
            ByteArrayOutputStream line = new ByteArrayOutputStream();
            byte[] buffer = new byte[128];
            try {
                InputStream stream = activeSocket.getInputStream();
                int count;
                while (connected && activeSocket.isConnected() && (count = stream.read(buffer)) != -1) {
                    for (int i = 0; i < count; i++) {
                        int b = buffer[i] & 0xFF;
                        if (b == '\n') {
                            String received = line.toString(StandardCharsets.US_ASCII.name()).trim();
                            line.reset();
                            if (!received.isEmpty()) {
                                if (!receivedLines.offer(received)) {
                                    receivedLines.poll();
                                    receivedLines.offer(received);
                                }
                                handleDeviceLine(received);
                            }
                        } else if (b >= 32 && b <= 126) {
                            if (line.size() < 512) line.write(b);
                            else line.reset();
                        }
                    }
                }
                if (connected && socket == activeSocket) {
                    mainHandler.post(() -> disconnectBluetooth("Bluetooth device disconnected."));
                }
            } catch (IOException e) {
                if (connected) {
                    mainHandler.post(() -> {
                        addLog("Bluetooth connection lost: " + e.getMessage());
                        disconnectBluetooth("Connection closed.");
                    });
                }
            }
        });
    }

    private void sendCommand(String command) {
        BluetoothSocket active = socket;
        if (!connected || active == null || !active.isConnected()) {
            showToast("Connect to HC-05 first.");
            return;
        }

        /* Ignore repeated taps while a complete command/response transaction
           is in progress. This prevents overlapping STATUS requests. */
        if (!commandBusy.compareAndSet(false, true)) {
            showToast("Please wait for the current device response.");
            return;
        }
        refreshCommandButtons();

        commandExecutor.execute(() -> {
            try {
                if (!connected || socket != active || !active.isConnected()) {
                    return;
                }

                /* Remove stale responses from a previous transaction. */
                receivedLines.clear();
                writeLine(command, active);

                if ("STATUS".equals(command)) {
                    String status = awaitDeviceResponse(true, 1800);
                    if (status == null) {
                        mainHandler.post(() -> addLog("TIMEOUT  No STATUS response from Tiva."));
                    }
                    return;
                }

                /* Wait for the firmware acknowledgement before requesting
                   status. The reader remains independent and keeps receiving. */
                String ack = awaitDeviceResponse(false, 1000);
                if (ack == null) {
                    mainHandler.post(() -> addLog("TIMEOUT  No command acknowledgement."));
                }

                if (connected && socket == active && active.isConnected()) {
                    receivedLines.clear();
                    writeLine("STATUS", active);
                    String status = awaitDeviceResponse(true, 1800);
                    if (status == null) {
                        mainHandler.post(() -> addLog("TIMEOUT  No STATUS response after command."));
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                mainHandler.post(() -> addLog("Command transaction interrupted."));
            } catch (Exception e) {
                String message = e.getMessage() == null ?
                        e.getClass().getSimpleName() : e.getMessage();
                mainHandler.post(() -> addLog("Communication error: " + message));
            } finally {
                commandBusy.set(false);
                mainHandler.post(this::refreshCommandButtons);
            }
        });
    }

    private String awaitDeviceResponse(boolean wantStatus, long timeoutMs)
            throws InterruptedException {
        long deadline = android.os.SystemClock.elapsedRealtime() + timeoutMs;
        while (connected) {
            long remaining = deadline - android.os.SystemClock.elapsedRealtime();
            if (remaining <= 0) return null;

            String line = receivedLines.poll(remaining, TimeUnit.MILLISECONDS);
            if (line == null) return null;

            if (wantStatus) {
                if (line.contains("LAMP=") && line.contains("PLUG=") &&
                        line.contains("DOOR=") && line.contains("TEMP=")) {
                    return line;
                }
            } else if (line.startsWith("OK ") || line.startsWith("ERR ")) {
                return line;
            }
            /* Ignore unrelated asynchronous events; they are still displayed
               and parsed by handleDeviceLine(). */
        }
        return null;
    }

    private void writeLine(String command, BluetoothSocket active) throws IOException {
        synchronized (outputLock) {
            OutputStream stream = active.getOutputStream();
            /* Enqueue the TX log before writing so a very fast RX cannot appear
               above the command that caused it. */
            mainHandler.post(() -> addLog("TX  " + command));
            stream.write((command + "\r\n").getBytes(StandardCharsets.US_ASCII));
            stream.flush();
        }
    }

    private void handleDeviceLine(String line) {
        mainHandler.post(() -> {
            addLog("RX  " + line);

            Matcher m = LAMP_PATTERN.matcher(line);
            if (m.find()) lampState = m.group(1);
            m = PLUG_PATTERN.matcher(line);
            if (m.find()) plugState = m.group(1);
            m = DOOR_PATTERN.matcher(line);
            if (m.find()) doorState = m.group(1);
            m = TEMP_PATTERN.matcher(line);
            if (m.find()) temperature = m.group(1) + " °C";

            if (line.equals("DOOR=OPEN")) doorState = "OPEN";
            if (line.equals("DOOR=CLOSED")) doorState = "CLOSED";

            updateAllViews();
        });
    }

    private void disconnectBluetooth(String reason) {
        connected = false;
        BluetoothSocket old = socket;
        socket = null;
        input = null;
        output = null;
        closeQuietly(old);
        setConnecting(false, "DISCONNECTED");
        addLog(reason);
    }

    private void closeQuietly(BluetoothSocket s) {
        if (s != null) {
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    private void setConnecting(boolean connecting, String label) {
        connectionText.setText(label);
        connectionText.setTextColor("CONNECTED".equals(label) ? TEAL :
                ("CONNECTING…".equals(label) ? AMBER : MUTED));
        connectButton.setText(connecting ? "Connecting…" : (connected ? "Disconnect" : "Connect"));
        connectButton.setEnabled(!connecting);
        refreshDevicesButton.setEnabled(!connecting && !connected);
        statusButton.setEnabled(connected);
        refreshCommandButtons();
    }

    private void refreshCommandButtons() {
        boolean enabled = connected && !commandBusy.get();
        statusButton.setEnabled(enabled);
        setControlButtonsEnabled(enabled);
    }

    private void setControlButtonsEnabled(boolean enabled) {
        if (lampOnButton != null) {
            lampOnButton.setEnabled(enabled);
            lampOffButton.setEnabled(enabled);
            plugOnButton.setEnabled(enabled);
            plugOffButton.setEnabled(enabled);
        }
    }

    private void updateAllViews() {
        if (temperatureText == null) return;
        temperatureText.setText(temperature);
        doorText.setText("OPEN".equals(doorState) ? "Open" :
                ("CLOSED".equals(doorState) ? "Closed" : "Unknown"));
        doorText.setTextColor("OPEN".equals(doorState) ? RED :
                ("CLOSED".equals(doorState) ? TEAL : TEXT));
        lampStateText.setText(lampState);
        lampStateText.setTextColor(stateColor(lampState));
        plugStateText.setText(plugState);
        plugStateText.setTextColor(stateColor(plugState));
        refreshCommandButtons();
    }

    private int stateColor(String state) {
        if ("ON".equals(state) || "CLOSED".equals(state)) return TEAL;
        if ("OFF".equals(state) || "OPEN".equals(state)) return AMBER;
        return MUTED;
    }

    private void addLog(String message) {
        if (logText == null) return;
        logLines.add(message);
        while (logLines.size() > 9) logLines.remove(0);
        StringBuilder text = new StringBuilder();
        for (String entry : logLines) {
            if (text.length() > 0) text.append('\n');
            text.append("› ").append(entry);
        }
        logText.setText(text.toString());
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        disconnectBluetooth("App closed.");
        ioExecutor.shutdownNow();
        commandExecutor.shutdownNow();
        super.onDestroy();
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(tintDrawable(CARD, 18));
        return box;
    }

    private LinearLayout miniCard() {
        LinearLayout box = card();
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        return box;
    }

    private LinearLayout horizontal() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private TextView sectionTitle(String value) {
        TextView t = text(value, 11, MUTED, true);
        t.setLetterSpacing(0.12f);
        return t;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? BG : TEXT);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setBackground(tintDrawable(primary ? TEAL : CARD_ALT, 12));
        b.setMinHeight(dp(44));
        b.setStateListAnimator(null);
        return b;
    }

    private GradientDrawable tintDrawable(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private LinearLayout.LayoutParams margin(int width, int height,
                                             int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, height);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
}
