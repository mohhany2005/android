package com.tivahome.automation;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

public class MainActivity extends Activity implements ProtocolEngine.Listener {
    private static final int REQ_BT_CONNECT = 410;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String HC05_ADDRESS = "00:24:08:00:53:9D";
    private static final String DEFAULT_LIMIT = "30";
    private static final int MAX_HISTORY = 500;

    private static final int BG = Color.rgb(16, 24, 39);
    private static final int CARD = Color.rgb(27, 39, 58);
    private static final int CARD_ALT = Color.rgb(34, 48, 69);
    private static final int TEXT = Color.rgb(240, 245, 250);
    private static final int MUTED = Color.rgb(157, 174, 193);
    private static final int TEAL = Color.rgb(25, 183, 165);
    private static final int RED = Color.rgb(239, 91, 91);
    private static final int AMBER = Color.rgb(244, 184, 75);
    private static final int GREEN_DARK = Color.rgb(24, 72, 67);
    private static final int RED_DARK = Color.rgb(87, 39, 48);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService connectExecutor = Executors.newSingleThreadExecutor();
    private final Pattern integerPattern = Pattern.compile("[+-]?\\d+");
    private final List<BluetoothDevice> pairedDevices = new ArrayList<>();
    private final List<String> logLines = new ArrayList<>();
    private final List<DoorEvent> doorHistory = new ArrayList<>();
    private final List<ConnectionGap> connectionGaps = new ArrayList<>();

    private BluetoothAdapter bluetoothAdapter;
    private volatile BluetoothSocket socket;
    private volatile ProtocolEngine protocol;
    private volatile boolean connected;
    private volatile boolean connectionInProgress;
    private SharedPreferences preferences;

    private String confirmedLimit = DEFAULT_LIMIT;
    private String lampState = "UNKNOWN";
    private String plugState = "UNKNOWN";
    private String doorState = "UNKNOWN";
    private Double temperatureC;
    private boolean temperatureError;
    private long lastTemperatureElapsed;
    private boolean alarmActive;
    private long nextDoorId = 1L;
    private int currentScreen;

    private LinearLayout content;
    private Spinner deviceSpinner;
    private TextView headerConnection;
    private TextView logText;
    private TextView temperatureText;
    private TextView temperatureFreshText;
    private TextView doorText;
    private TextView lampStateText;
    private TextView plugStateText;
    private TextView alarmBanner;
    private TextView limitConfirmedText;
    private TextView historyText;
    private EditText limitInput;
    private Button connectButton;
    private Button refreshDevicesButton;
    private Button statusButton;
    private Button lampOnButton, lampOffButton, plugOnButton, plugOffButton, applyLimitButton;
    private Button connectionTab, dashboardTab, historyTab;

    private final Runnable freshnessTicker = new Runnable() {
        @Override public void run() {
            updateTemperatureFreshness();
            mainHandler.postDelayed(this, 500L);
        }
    };

    private static final class DoorEvent {
        long id;
        String state;
        long timestampUtc;
        String timezoneId;
        int offsetMinutes;
        String deviceAddress;
    }

    private static final class ConnectionGap {
        long startUtc;
        long endUtc;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        preferences = getSharedPreferences("tiva_home_preferences", MODE_PRIVATE);
        confirmedLimit = preferences.getString("temperature_limit", DEFAULT_LIMIT);
        if (!isValidLimit(confirmedLimit)) confirmedLimit = DEFAULT_LIMIT;
        loadDoorHistory();
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        buildShell();
        renderScreen(0);
        setConnectionState("DISCONNECTED");
        mainHandler.post(freshnessTicker);
        checkBluetoothPermissionAndLoad();
    }

    private void buildShell() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(BG);
        outer.setPadding(dp(18), dp(18), dp(18), dp(14));

        TextView eyebrow = text("SMART HOME  •  TM4C123GH6PM", 10, TEAL, true);
        eyebrow.setLetterSpacing(0.12f);
        outer.addView(eyebrow, lp(MATCH, WRAP, 0, 0, 0, 5));

        LinearLayout header = horizontal();
        TextView title = text("Tiva Home", 28, TEXT, true);
        header.addView(title, new LinearLayout.LayoutParams(0, WRAP, 1));
        headerConnection = text("DISCONNECTED", 10, AMBER, true);
        header.addView(headerConnection);
        outer.addView(header, lp(MATCH, WRAP, 0, 0, 0, 14));

        LinearLayout nav = horizontal();
        connectionTab = navButton("Connection");
        dashboardTab = navButton("Dashboard");
        historyTab = navButton("Door history");
        nav.addView(connectionTab, new LinearLayout.LayoutParams(0, dp(42), 1));
        LinearLayout.LayoutParams n2 = new LinearLayout.LayoutParams(0, dp(42), 1);
        n2.leftMargin = dp(6);
        nav.addView(dashboardTab, n2);
        LinearLayout.LayoutParams n3 = new LinearLayout.LayoutParams(0, dp(42), 1);
        n3.leftMargin = dp(6);
        nav.addView(historyTab, n3);
        outer.addView(nav, lp(MATCH, WRAP, 0, 0, 0, 12));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        outer.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1));

        connectionTab.setOnClickListener(v -> renderScreen(0));
        dashboardTab.setOnClickListener(v -> renderScreen(1));
        historyTab.setOnClickListener(v -> renderScreen(2));
        setContentView(outer);
    }

    private void renderScreen(int screen) {
        currentScreen = screen;
        if (content == null) return;
        // Drop references to views from the previous tab; protocol state lives separately.
        deviceSpinner = null;
        connectButton = null;
        refreshDevicesButton = null;
        statusButton = null;
        lampOnButton = null; lampOffButton = null;
        plugOnButton = null; plugOffButton = null;
        applyLimitButton = null; limitInput = null; limitConfirmedText = null;
        temperatureText = null; temperatureFreshText = null; doorText = null;
        lampStateText = null; plugStateText = null; alarmBanner = null;
        historyText = null; logText = null;
        content.removeAllViews();
        setTabStyle(connectionTab, screen == 0);
        setTabStyle(dashboardTab, screen == 1);
        setTabStyle(historyTab, screen == 2);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(0, 0, 0, dp(20));
        scroll.addView(page);
        content.addView(scroll, new LinearLayout.LayoutParams(MATCH, MATCH));
        if (screen == 0) renderConnectionScreen(page);
        else if (screen == 1) renderDashboardScreen(page);
        else renderHistoryScreen(page);
    }

    private void renderConnectionScreen(LinearLayout page) {
        LinearLayout box = card();
        page.addView(box, lp(MATCH, WRAP, 0, 0, 0, 12));
        box.addView(text("Bluetooth Classic connection", 17, TEXT, true));
        TextView hint = text("Pair the HC-05 in Android Bluetooth settings first. Enter PIN 1234 if Android asks.", 12, MUTED, false);
        hint.setLineSpacing(dp(3), 1f);
        box.addView(hint, lp(MATCH, WRAP, 0, 8, 0, 12));
        TextView address = text("HC-05 address: " + HC05_ADDRESS, 11, MUTED, false);
        address.setTypeface(Typeface.MONOSPACE);
        box.addView(address, lp(MATCH, WRAP, 0, 0, 0, 10));

        deviceSpinner = new Spinner(this);
        deviceSpinner.setBackground(tintDrawable(CARD_ALT, 12));
        box.addView(deviceSpinner, lp(MATCH, dp(48), 0, 0, 0, 10));
        LinearLayout row = horizontal();
        Button pair = button("Pair in Settings", false);
        refreshDevicesButton = button("Refresh list", false);
        connectButton = button(connected ? "Disconnect" : "Connect", true);
        row.addView(pair, new LinearLayout.LayoutParams(0, dp(46), 1));
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dp(46), 1);
        p2.leftMargin = dp(6); row.addView(refreshDevicesButton, p2);
        LinearLayout.LayoutParams p3 = new LinearLayout.LayoutParams(0, dp(46), 1);
        p3.leftMargin = dp(6); row.addView(connectButton, p3);
        box.addView(row);
        box.addView(text("RFCOMM / SPP  •  UART1  •  9600 baud  •  8-N-1  •  PB0/PB1", 10, MUTED, false), lp(MATCH, WRAP, 0, 12, 0, 0));

        pair.setOnClickListener(v -> startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)));
        refreshDevicesButton.setOnClickListener(v -> checkBluetoothPermissionAndLoad());
        connectButton.setOnClickListener(v -> {
            if (connected) disconnectBluetooth("Disconnected by user.");
            else connectSelectedDevice();
        });
        loadPairedDevicesIfPossible();
        addLogSection(page);
    }

    private void renderDashboardScreen(LinearLayout page) {
        page.addView(sectionTitle("LIVE ROOM STATUS"), lp(MATCH, WRAP, 0, 2, 0, 8));
        alarmBanner = text("NO ACTIVE TEMPERATURE ALARM", 12, TEXT, true);
        alarmBanner.setPadding(dp(13), dp(12), dp(13), dp(12));
        page.addView(alarmBanner, lp(MATCH, WRAP, 0, 0, 0, 12));

        LinearLayout sensorRow = horizontal();
        page.addView(sensorRow, lp(MATCH, WRAP, 0, 0, 0, 12));
        LinearLayout temp = miniCard();
        LinearLayout door = miniCard();
        sensorRow.addView(temp, new LinearLayout.LayoutParams(0, dp(132), 1));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(0, dp(132), 1);
        dlp.leftMargin = dp(10); sensorRow.addView(door, dlp);
        temp.addView(text("TEMPERATURE", 10, MUTED, true));
        temperatureText = text("--.- °C", 24, TEXT, true);
        temp.addView(temperatureText, lp(MATCH, WRAP, 0, 10, 0, 4));
        temperatureFreshText = text("Waiting for sensor", 10, MUTED, false);
        temp.addView(temperatureFreshText);
        door.addView(text("DOOR SENSOR", 10, MUTED, true));
        doorText = text("UNKNOWN", 21, TEXT, true);
        door.addView(doorText, lp(MATCH, WRAP, 0, 13, 0, 4));
        door.addView(text("Live state", 10, MUTED, false));

        page.addView(sectionTitle("APPLIANCE CONTROL"), lp(MATCH, WRAP, 0, 4, 0, 8));
        addApplianceCard(page, "Lamp relay", true);
        addApplianceCard(page, "Socket / plug relay", false);

        LinearLayout limit = card();
        page.addView(limit, lp(MATCH, WRAP, 0, 0, 0, 12));
        limit.addView(text("TEMPERATURE LIMIT", 11, MUTED, true));
        limit.addView(text("Enter a signed whole number in °C. The saved limit is restored after reconnecting.", 11, MUTED, false), lp(MATCH, WRAP, 0, 5, 0, 10));
        LinearLayout lr = horizontal();
        limitInput = new EditText(this);
        limitInput.setSingleLine(true);
        limitInput.setTextSize(16);
        limitInput.setTextColor(TEXT);
        limitInput.setHintTextColor(MUTED);
        limitInput.setHint("e.g. 30");
        limitInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        limitInput.setText(confirmedLimit);
        limitInput.setPadding(dp(12), 0, dp(12), 0);
        limitInput.setBackground(tintDrawable(CARD_ALT, 10));
        lr.addView(limitInput, new LinearLayout.LayoutParams(0, dp(48), 1));
        applyLimitButton = button("Apply limit", true);
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(dp(126), dp(48));
        al.leftMargin = dp(8); lr.addView(applyLimitButton, al);
        limit.addView(lr);
        limitConfirmedText = text("Confirmed limit: " + confirmedLimit + " °C", 11, MUTED, false);
        limit.addView(limitConfirmedText, lp(MATCH, WRAP, 0, 8, 0, 0));
        applyLimitButton.setOnClickListener(v -> applyTemperatureLimit());

        statusButton = button("Refresh status", false);
        page.addView(statusButton, lp(MATCH, dp(48), 0, 0, 0, 14));
        statusButton.setOnClickListener(v -> { if (protocol != null) protocol.refreshStatus(); });
        addLogSection(page);
        updateDashboardViews();
        updateCommandButtons();
    }

    private void addApplianceCard(LinearLayout page, String title, boolean lamp) {
        LinearLayout box = card();
        page.addView(box, lp(MATCH, WRAP, 0, 0, 0, 10));
        LinearLayout top = horizontal();
        box.addView(top);
        top.addView(text(title, 16, TEXT, true), new LinearLayout.LayoutParams(0, WRAP, 1));
        TextView state = text("UNKNOWN", 11, AMBER, true);
        top.addView(state);
        LinearLayout actions = horizontal();
        box.addView(actions, lp(MATCH, WRAP, 0, 10, 0, 0));
        Button on = button("ON", true);
        Button off = button("OFF", false);
        actions.addView(on, new LinearLayout.LayoutParams(0, dp(44), 1));
        LinearLayout.LayoutParams offLp = new LinearLayout.LayoutParams(0, dp(44), 1);
        offLp.leftMargin = dp(8); actions.addView(off, offLp);
        if (lamp) {
            lampStateText = state; lampOnButton = on; lampOffButton = off;
            on.setOnClickListener(v -> { if (protocol != null) protocol.setRelay("LAMP:1"); });
            off.setOnClickListener(v -> { if (protocol != null) protocol.setRelay("LAMP:0"); });
        } else {
            plugStateText = state; plugOnButton = on; plugOffButton = off;
            on.setOnClickListener(v -> { if (protocol != null) protocol.setRelay("PLUG:1"); });
            off.setOnClickListener(v -> { if (protocol != null) protocol.setRelay("PLUG:0"); });
        }
    }

    private void renderHistoryScreen(LinearLayout page) {
        page.addView(sectionTitle("DOOR EVENT HISTORY"), lp(MATCH, WRAP, 0, 2, 0, 8));
        TextView hint = text("Only live DOOR:OPEN / DOOR:CLOSED events are stored. DOOR fields inside a STATUS snapshot are not logged as events.", 12, MUTED, false);
        hint.setLineSpacing(dp(3), 1f);
        page.addView(hint, lp(MATCH, WRAP, 0, 0, 0, 12));
        LinearLayout box = card();
        page.addView(box, new LinearLayout.LayoutParams(MATCH, WRAP));
        historyText = text("", 12, TEXT, false);
        historyText.setLineSpacing(dp(6), 1f);
        box.addView(historyText);
        renderHistoryText();
    }

    private void addLogSection(LinearLayout page) {
        page.addView(sectionTitle("DEVICE MESSAGES"), lp(MATCH, WRAP, 0, 4, 0, 8));
        LinearLayout box = card();
        page.addView(box, new LinearLayout.LayoutParams(MATCH, WRAP));
        logText = text("No messages yet.", 11, MUTED, false);
        logText.setTypeface(Typeface.MONOSPACE);
        logText.setLineSpacing(dp(3), 1f);
        box.addView(logText);
        updateLogText();
    }

    private void addLog(String message) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(() -> addLog(message));
            return;
        }
        String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        logLines.add(time + "  " + message);
        while (logLines.size() > 28) logLines.remove(0);
        updateLogText();
    }

    private void updateLogText() {
        if (logText == null) return;
        StringBuilder b = new StringBuilder();
        for (String line : logLines) {
            if (b.length() > 0) b.append('\n');
            b.append("› ").append(line);
        }
        logText.setText(b.length() == 0 ? "No messages yet." : b.toString());
    }

    private void checkBluetoothPermissionAndLoad() {
        if (bluetoothAdapter == null) { showToast("This phone does not support Bluetooth."); return; }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_CONNECT);
            return;
        }
        loadPairedDevices();
        if (!bluetoothAdapter.isEnabled()) {
            showToast("Turn Bluetooth on, then refresh the paired-device list.");
            startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_CONNECT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) loadPairedDevices();
            else showToast("Nearby devices permission is required to connect to HC-05.");
        }
    }

    private void loadPairedDevicesIfPossible() {
        if (bluetoothAdapter == null) return;
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return;
        loadPairedDevices();
    }

    private void loadPairedDevices() {
        if (bluetoothAdapter == null) return;
        try {
            Set<BluetoothDevice> bonded = bluetoothAdapter.getBondedDevices();
            pairedDevices.clear();
            if (bonded != null) pairedDevices.addAll(bonded);
            Collections.sort(pairedDevices, (a, b) -> {
                boolean aKnown = HC05_ADDRESS.equalsIgnoreCase(safeAddress(a));
                boolean bKnown = HC05_ADDRESS.equalsIgnoreCase(safeAddress(b));
                if (aKnown != bKnown) return aKnown ? -1 : 1;
                return safeName(a).compareToIgnoreCase(safeName(b));
            });
            if (deviceSpinner != null) {
                List<String> labels = new ArrayList<>();
                if (pairedDevices.isEmpty()) labels.add("No paired devices — pair HC-05 in Settings");
                else for (BluetoothDevice d : pairedDevices) labels.add(safeName(d) + "  •  " + safeAddress(d));
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                deviceSpinner.setAdapter(adapter);
            }
            addLog(pairedDevices.size() + " paired Bluetooth device(s) found.");
        } catch (SecurityException e) { addLog("Bluetooth permission missing."); }
    }

    private String safeName(BluetoothDevice d) {
        try { String n = d.getName(); return n == null || n.trim().isEmpty() ? "Bluetooth device" : n; }
        catch (SecurityException e) { return "Bluetooth device"; }
    }

    private String safeAddress(BluetoothDevice d) {
        try { return d.getAddress(); } catch (SecurityException e) { return ""; }
    }

    private void connectSelectedDevice() {
        if (bluetoothAdapter == null) return;
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            checkBluetoothPermissionAndLoad(); return;
        }
        if (!bluetoothAdapter.isEnabled()) {
            startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));
            showToast("Enable Bluetooth first."); return;
        }
        int index = deviceSpinner == null ? -1 : deviceSpinner.getSelectedItemPosition();
        if (index < 0 || index >= pairedDevices.size()) {
            showToast("Pair the HC-05 first. PIN: 1234 if requested.");
            startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)); return;
        }
        BluetoothDevice device = pairedDevices.get(index);
        connectionInProgress = true;
        setConnectionState("CONNECTING");
        addLog("Connecting to " + safeName(device) + " (" + safeAddress(device) + ")...");
        connectExecutor.execute(() -> {
            BluetoothSocket candidate = null;
            try {
                candidate = device.createRfcommSocketToServiceRecord(SPP_UUID);
                candidate.connect();
                socket = candidate;
                ProtocolEngine engine = new ProtocolEngine(candidate.getInputStream(), candidate.getOutputStream(), this);
                protocol = engine;
                closeOpenConnectionGap();
                connected = true;
                connectionInProgress = false;
                mainHandler.post(() -> {
                    setConnectionState("CONNECTED");
                    addLog("Connected to " + safeName(device) + ".");
                    showToast("HC-05 connected.");
                });
                engine.start();
                String saved = preferences.getString("temperature_limit", DEFAULT_LIMIT);
                if (!isValidLimit(saved)) saved = DEFAULT_LIMIT;
                engine.initialize(saved);
            } catch (Exception e) {
                if (candidate != null) try { candidate.close(); } catch (IOException ignored) { }
                if (socket == candidate) socket = null;
                ProtocolEngine old = protocol;
                protocol = null;
                if (old != null) old.close();
                connected = false;
                connectionInProgress = false;
                String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                mainHandler.post(() -> {
                    setConnectionState("DISCONNECTED");
                    addLog("Connection failed: " + message);
                    showToast("Connection failed. Check HC-05 pairing and power.");
                });
            }
        });
    }

    private void disconnectBluetooth(String reason) {
        boolean wasConnected = connected;
        connected = false;
        connectionInProgress = false;
        if (wasConnected) recordConnectionGap();
        ProtocolEngine old = protocol;
        protocol = null;
        BluetoothSocket oldSocket = socket;
        socket = null;
        if (old != null) old.close();
        if (oldSocket != null) try { oldSocket.close(); } catch (IOException ignored) { }
        setConnectionState("DISCONNECTED");
        addLog(reason);
        updateTemperatureFreshness();
    }

    private void applyTemperatureLimit() {
        if (!connected || protocol == null) { showToast("Connect to HC-05 first."); return; }
        String candidate = limitInput == null ? "" : limitInput.getText().toString().trim();
        if (!isValidLimit(candidate)) { showToast("Enter a whole number from -2147483648 to 2147483647."); return; }
        protocol.setLimit(candidate);
    }

    private boolean isValidLimit(String value) {
        if (value == null || !integerPattern.matcher(value).matches()) return false;
        try {
            long n = Long.parseLong(value);
            return n >= Integer.MIN_VALUE && n <= Integer.MAX_VALUE;
        } catch (NumberFormatException e) { return false; }
    }

    private void updateDashboardViews() {
        if (temperatureText == null) return;
        if (temperatureError) {
            temperatureText.setText("Sensor error"); temperatureText.setTextColor(RED);
        } else if (temperatureC == null) {
            temperatureText.setText("--.- °C"); temperatureText.setTextColor(TEXT);
        } else {
            temperatureText.setText(String.format(Locale.getDefault(), "%.1f °C", temperatureC));
            temperatureText.setTextColor(TEXT);
        }
        doorText.setText(doorState);
        doorText.setTextColor("OPEN".equals(doorState) ? RED : ("CLOSED".equals(doorState) ? TEAL : MUTED));
        lampStateText.setText(lampState); lampStateText.setTextColor(stateColor(lampState));
        plugStateText.setText(plugState); plugStateText.setTextColor(stateColor(plugState));
        if (alarmActive) {
            alarmBanner.setText("TEMPERATURE ALERT  •  Above " + confirmedLimit + " °C");
            alarmBanner.setBackground(tintDrawable(RED_DARK, 12));
        } else {
            alarmBanner.setText("NO ACTIVE TEMPERATURE ALARM");
            alarmBanner.setBackground(tintDrawable(GREEN_DARK, 12));
        }
        if (limitConfirmedText != null) limitConfirmedText.setText("Confirmed limit: " + confirmedLimit + " °C");
        updateTemperatureFreshness();
    }

    private void updateTemperatureFreshness() {
        if (temperatureFreshText == null) return;
        if (!connected) {
            temperatureFreshText.setText("Disconnected • value may be stale"); temperatureFreshText.setTextColor(AMBER);
        } else if (temperatureError) {
            temperatureFreshText.setText("Sensor unavailable (TEMP:ERR)"); temperatureFreshText.setTextColor(RED);
        } else if (lastTemperatureElapsed == 0L || SystemClock.elapsedRealtime() - lastTemperatureElapsed > 3000L) {
            temperatureFreshText.setText("No update for 3+ seconds • stale"); temperatureFreshText.setTextColor(AMBER);
        } else {
            long age = SystemClock.elapsedRealtime() - lastTemperatureElapsed;
            temperatureFreshText.setText(String.format(Locale.getDefault(), "Live • updated %.1fs ago", age / 1000.0));
            temperatureFreshText.setTextColor(TEAL);
        }
    }

    private void updateCommandButtons() {
        boolean enabled = connected && protocol != null && !protocol.isBusy();
        if (statusButton != null) statusButton.setEnabled(enabled);
        if (lampOnButton != null) lampOnButton.setEnabled(enabled);
        if (lampOffButton != null) lampOffButton.setEnabled(enabled);
        if (plugOnButton != null) plugOnButton.setEnabled(enabled);
        if (plugOffButton != null) plugOffButton.setEnabled(enabled);
        if (applyLimitButton != null) applyLimitButton.setEnabled(enabled);
        if (connectButton != null) {
            connectButton.setText(connected ? "Disconnect" : (connectionInProgress ? "Connecting..." : "Connect"));
            connectButton.setEnabled(!connectionInProgress);
        }
    }

    private void setConnectionState(String state) {
        if (headerConnection != null) {
            headerConnection.setText(state);
            headerConnection.setTextColor("CONNECTED".equals(state) ? TEAL : ("CONNECTING".equals(state) ? AMBER : MUTED));
        }
        updateCommandButtons();
    }

    private void saveDoorEvent(String state) {
        long now = System.currentTimeMillis();
        TimeZone zone = TimeZone.getDefault();
        DoorEvent event = new DoorEvent();
        event.id = nextDoorId++;
        event.state = state;
        event.timestampUtc = now;
        event.timezoneId = zone.getID();
        event.offsetMinutes = zone.getOffset(now) / 60000;
        try { event.deviceAddress = socket == null ? HC05_ADDRESS : socket.getRemoteDevice().getAddress(); }
        catch (Exception e) { event.deviceAddress = HC05_ADDRESS; }
        doorHistory.add(0, event);
        while (doorHistory.size() > MAX_HISTORY) doorHistory.remove(doorHistory.size() - 1);
        persistDoorHistory();
        if (currentScreen == 2) renderHistoryText();
    }

    private void persistDoorHistory() {
        JSONArray array = new JSONArray();
        for (DoorEvent event : doorHistory) {
            JSONObject o = new JSONObject();
            try {
                o.put("id", event.id); o.put("state", event.state); o.put("timestampUtc", event.timestampUtc);
                o.put("timezoneId", event.timezoneId); o.put("offsetMinutes", event.offsetMinutes);
                o.put("deviceAddress", event.deviceAddress); array.put(o);
            } catch (JSONException ignored) { }
        }
        preferences.edit().putString("door_history", array.toString()).putLong("next_door_id", nextDoorId).apply();
    }

    private void loadDoorHistory() {
        nextDoorId = preferences.getLong("next_door_id", 1L);
        try {
            JSONArray array = new JSONArray(preferences.getString("door_history", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                DoorEvent event = new DoorEvent();
                event.id = o.optLong("id", i + 1L); event.state = o.optString("state", "UNKNOWN");
                event.timestampUtc = o.optLong("timestampUtc", 0L);
                event.timezoneId = o.optString("timezoneId", TimeZone.getDefault().getID());
                event.offsetMinutes = o.optInt("offsetMinutes", 0); event.deviceAddress = o.optString("deviceAddress", "");
                if (("OPEN".equals(event.state) || "CLOSED".equals(event.state)) && event.timestampUtc > 0L) doorHistory.add(event);
            }
        } catch (JSONException e) { doorHistory.clear(); }
        Collections.sort(doorHistory, (a, b) -> Long.compare(b.timestampUtc, a.timestampUtc));
        try {
            JSONArray gaps = new JSONArray(preferences.getString("connection_gaps", "[]"));
            for (int i = 0; i < gaps.length(); i++) {
                JSONObject o = gaps.getJSONObject(i);
                ConnectionGap gap = new ConnectionGap();
                gap.startUtc = o.optLong("startUtc", 0L);
                gap.endUtc = o.optLong("endUtc", 0L);
                if (gap.startUtc > 0L) connectionGaps.add(gap);
            }
        } catch (JSONException ignored) { connectionGaps.clear(); }
    }

    private void recordConnectionGap() {
        if (!connectionGaps.isEmpty() && connectionGaps.get(connectionGaps.size() - 1).endUtc == 0L) return;
        ConnectionGap gap = new ConnectionGap();
        gap.startUtc = System.currentTimeMillis();
        gap.endUtc = 0L;
        connectionGaps.add(gap);
        persistConnectionGaps();
        if (currentScreen == 2) renderHistoryText();
    }

    private void closeOpenConnectionGap() {
        if (connectionGaps.isEmpty()) return;
        ConnectionGap gap = connectionGaps.get(connectionGaps.size() - 1);
        if (gap.endUtc == 0L) {
            gap.endUtc = System.currentTimeMillis();
            persistConnectionGaps();
            if (currentScreen == 2) renderHistoryText();
        }
    }

    private void persistConnectionGaps() {
        JSONArray array = new JSONArray();
        for (ConnectionGap gap : connectionGaps) {
            JSONObject o = new JSONObject();
            try { o.put("startUtc", gap.startUtc); o.put("endUtc", gap.endUtc); array.put(o); }
            catch (JSONException ignored) { }
        }
        preferences.edit().putString("connection_gaps", array.toString()).apply();
    }

    private void renderHistoryText() {
        if (historyText == null) return;
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss", Locale.getDefault());
        fmt.setTimeZone(TimeZone.getDefault());
        StringBuilder b = new StringBuilder();
        if (!connectionGaps.isEmpty()) {
            b.append("CONNECTION GAPS\n");
            for (int i = connectionGaps.size() - 1; i >= 0; i--) {
                ConnectionGap gap = connectionGaps.get(i);
                b.append("⚠  Door events are unknown while disconnected\n   ")
                 .append(fmt.format(new Date(gap.startUtc)));
                if (gap.endUtc > 0L) b.append(" — ").append(fmt.format(new Date(gap.endUtc)));
                else b.append(" — still disconnected");
                b.append("\n\n");
            }
        }
        if (doorHistory.isEmpty()) {
            b.append("No door events recorded yet.\nEvents are saved when the board sends a live DOOR event.");
        } else {
            b.append("DOOR EVENTS\n");
            for (DoorEvent e : doorHistory) {
                if (b.length() > 0) b.append("\n\n");
                b.append("OPEN".equals(e.state) ? "●  DOOR OPENED" : "●  DOOR CLOSED");
                b.append("\n   ").append(fmt.format(new Date(e.timestampUtc)));
                if (e.deviceAddress != null && !e.deviceAddress.isEmpty()) b.append("\n   ").append(e.deviceAddress);
            }
        }
        historyText.setText(b.toString());
    }

    private int stateColor(String value) {
        if ("ON".equals(value) || "CLOSED".equals(value)) return TEAL;
        if ("OFF".equals(value) || "OPEN".equals(value)) return AMBER;
        return MUTED;
    }

    private void showToast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }

    // ProtocolEngine.Listener callbacks: all UI work is marshalled onto the main thread.
    @Override public void onLog(String message) { mainHandler.post(() -> addLog(message)); }
    @Override public void onBusyChanged(boolean busy) { mainHandler.post(this::updateCommandButtons); }
    @Override public void onSnapshot(ProtocolEngine.Snapshot s) {
        mainHandler.post(() -> {
            lampState = s.lamp; plugState = s.plug; doorState = s.door;
            temperatureError = s.temperatureError; temperatureC = s.temperature;
            lastTemperatureElapsed = SystemClock.elapsedRealtime(); alarmActive = s.alarm;
            updateDashboardViews(); addLog("STATUS snapshot applied atomically.");
        });
    }
    @Override public void onTemperature(Double value, boolean sensorError) {
        mainHandler.post(() -> {
            temperatureError = sensorError; temperatureC = value;
            lastTemperatureElapsed = SystemClock.elapsedRealtime(); updateDashboardViews();
        });
    }
    @Override public void onDoorEvent(String state) {
        mainHandler.post(() -> {
            doorState = state; saveDoorEvent(state); updateDashboardViews();
            addLog("Door event saved using phone time: " + state);
        });
    }
    @Override public void onAlarm(boolean active) {
        mainHandler.post(() -> { alarmActive = active; updateDashboardViews(); });
    }
    @Override public void onDeviceError(String error) {
        mainHandler.post(() -> { addLog("Device error: " + error); showToast("Tiva reported " + error); });
    }
    @Override public void onCommandResult(boolean success, String message) {
        mainHandler.post(() -> {
            addLog((success ? "OK  " : "FAILED  ") + message);
            if (!success) showToast("Not confirmed: " + message);
        });
    }
    @Override public void onDisconnected(String reason) {
        mainHandler.post(() -> {
            if (connected) disconnectBluetooth(reason);
        });
    }
    @Override public void onLimitConfirmed(String limit) {
        mainHandler.post(() -> {
            confirmedLimit = limit;
            preferences.edit().putString("temperature_limit", limit).apply();
            if (limitInput != null) limitInput.setText(limit);
            if (limitConfirmedText != null) limitConfirmedText.setText("Confirmed limit: " + limit + " °C");
            updateDashboardViews();
        });
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(15), dp(15), dp(15), dp(15)); box.setBackground(tintDrawable(CARD, 17)); return box;
    }
    private LinearLayout miniCard() { LinearLayout b = card(); b.setPadding(dp(13), dp(13), dp(13), dp(13)); return b; }
    private LinearLayout horizontal() { LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); return r; }
    private TextView sectionTitle(String value) { TextView t = text(value, 10, MUTED, true); t.setLetterSpacing(0.12f); return t; }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private Button button(String label, boolean primary) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setTextColor(primary ? BG : TEXT);
        b.setPadding(dp(8), 0, dp(8), 0); b.setBackground(tintDrawable(primary ? TEAL : CARD_ALT, 11));
        b.setMinHeight(dp(42)); b.setStateListAnimator(null); return b;
    }
    private Button navButton(String label) { return button(label, false); }
    private void setTabStyle(Button b, boolean selected) { b.setBackground(tintDrawable(selected ? TEAL : CARD_ALT, 12)); b.setTextColor(selected ? BG : TEXT); }
    private GradientDrawable tintDrawable(int color, int radiusDp) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radiusDp)); return d; }
    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h); p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p;
    }
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    @Override protected void onDestroy() {
        mainHandler.removeCallbacks(freshnessTicker);
        if (connected) recordConnectionGap();
        connected = false;
        ProtocolEngine old = protocol; protocol = null; if (old != null) old.close();
        BluetoothSocket oldSocket = socket; socket = null;
        if (oldSocket != null) try { oldSocket.close(); } catch (IOException ignored) { }
        connectExecutor.shutdownNow();
        super.onDestroy();
    }
}
