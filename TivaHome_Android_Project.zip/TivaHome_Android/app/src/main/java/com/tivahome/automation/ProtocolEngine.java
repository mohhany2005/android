package com.tivahome.automation;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

/**
 * HC-05 line protocol for the working TM4C123 firmware.
 * Transport remains Bluetooth Classic RFCOMM/SPP. All commands are serialized.
 */
final class ProtocolEngine {
    interface Listener {
        void onLog(String message);
        void onBusyChanged(boolean busy);
        void onSnapshot(Snapshot snapshot);
        void onTemperature(Double value, boolean sensorError);
        void onDoorEvent(String state);
        void onAlarm(boolean active);
        void onDeviceError(String error);
        void onCommandResult(boolean success, String message);
        void onDisconnected(String reason);
        void onLimitConfirmed(String limit);
    }

    static final class Snapshot {
        String lamp;
        String plug;
        String door;
        Double temperature;
        boolean temperatureError;
        boolean alarm;
    }

    private static final long ACK_TIMEOUT_MS = 2000L;
    private static final long SNAPSHOT_TIMEOUT_MS = 2000L;
    private static final int MAX_LINE_BYTES = 128;
    private static final Pattern TEMP = Pattern.compile("-?\\d+(?:\\.\\d+)?");

    private final InputStream input;
    private final OutputStream output;
    private final Listener listener;
    private final ExecutorService readerExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService commandExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private final Object outputLock = new Object();
    private final Object pendingLock = new Object();
    private volatile boolean running = true;
    private Pending pending;
    private int discardSnapshotLines;

    private static final class Pending {
        final String command;
        final String expectedAck;
        final boolean status;
        final CountDownLatch ack = new CountDownLatch(1);
        final CountDownLatch snapshotDone = new CountDownLatch(1);
        final Snapshot snapshot = new Snapshot();
        volatile String error;
        volatile boolean ackReceived;
        int index;

        Pending(String command, boolean status) {
            this.command = command;
            this.expectedAck = "ACK:" + command;
            this.status = status;
        }
    }

    ProtocolEngine(InputStream input, OutputStream output, Listener listener) {
        this.input = input;
        this.output = output;
        this.listener = listener;
    }

    void start() {
        readerExecutor.execute(this::readLoop);
    }

    boolean isBusy() { return busy.get(); }

    void initialize(String savedLimit) {
        submit("Connection initialization", () -> {
            transact("LIMIT:" + savedLimit, false);
            listener.onLimitConfirmed(savedLimit);
            requestStatusWithRecovery();
        });
    }

    void setRelay(String command) {
        submit(command, () -> {
            transact(command, false);
            requestStatusWithRecovery();
        });
    }

    void setLimit(String limit) {
        submit("LIMIT:" + limit, () -> {
            transact("LIMIT:" + limit, false);
            listener.onLimitConfirmed(limit);
            requestStatusWithRecovery();
        });
    }

    void refreshStatus() {
        submit("STATUS?", this::requestStatusWithRecovery);
    }

    private interface Work { void run() throws Exception; }

    private void submit(String label, Work work) {
        if (!running) return;
        if (!busy.compareAndSet(false, true)) {
            listener.onCommandResult(false, "Please wait for the current device response.");
            return;
        }
        listener.onBusyChanged(true);
        commandExecutor.execute(() -> {
            try {
                work.run();
                listener.onCommandResult(true, label + " confirmed.");
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                listener.onCommandResult(false, message);
            } finally {
                busy.set(false);
                listener.onBusyChanged(false);
            }
        });
    }

    private void requestStatusWithRecovery() throws Exception {
        Exception last = null;
        for (int attempt = 1; attempt <= 2 && running; attempt++) {
            try {
                transact("STATUS?", true);
                return;
            } catch (Exception e) {
                last = e;
                listener.onLog("STATUS attempt " + attempt + " failed: " + e.getMessage());
                if (attempt == 1) Thread.sleep(150L);
            }
        }
        throw last == null ? new IOException("STATUS failed.") : last;
    }

    private void transact(String command, boolean status) throws Exception {
        if (!running) throw new IOException("Bluetooth connection is closed.");
        Pending p = new Pending(command, status);
        synchronized (pendingLock) {
            if (pending != null) throw new IOException("A command is already in progress.");
            pending = p;
        }
        try {
            writeCommand(command);
            if (!p.ack.await(ACK_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                throw new IOException("Timed out waiting for " + p.expectedAck);
            }
            if (p.error != null) throw new IOException(p.error);
            if (status) {
                if (!p.snapshotDone.await(SNAPSHOT_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    synchronized (pendingLock) {
                        if (p.ackReceived) discardSnapshotLines = Math.max(discardSnapshotLines, 5 - p.index);
                    }
                    throw new IOException("Timed out waiting for the ordered five-line STATUS snapshot.");
                }
                if (p.error != null) throw new IOException(p.error);
            }
        } finally {
            synchronized (pendingLock) {
                if (pending == p) pending = null;
            }
        }
    }

    private void writeCommand(String command) throws IOException {
        byte[] bytes = (command + "\n").getBytes(StandardCharsets.US_ASCII);
        synchronized (outputLock) {
            listener.onLog("TX " + command);
            output.write(bytes);
            output.flush();
        }
    }

    private void readLoop() {
        ByteArrayOutputStream line = new ByteArrayOutputStream();
        StringBuilder invalidHex = new StringBuilder();
        boolean invalid = false;
        boolean tooLong = false;
        byte[] buffer = new byte[128];
        try {
            int count;
            while (running && (count = input.read(buffer)) != -1) {
                for (int i = 0; i < count; i++) {
                    int value = buffer[i] & 0xFF;
                    if (value == 0x0A) {
                        if (invalid || tooLong) {
                            listener.onLog(tooLong
                                    ? "RX INVALID: line too long; bytes=" + invalidHex
                                    : "RX INVALID ASCII bytes: " + invalidHex);
                        } else {
                            byte[] raw = line.toByteArray();
                            int length = raw.length;
                            if (length > 0 && raw[length - 1] == 0x0D) length--;
                            String decoded = new String(raw, 0, length, StandardCharsets.US_ASCII);
                            if (!decoded.isEmpty()) handleLine(decoded);
                        }
                        line.reset();
                        invalidHex.setLength(0);
                        invalid = false;
                        tooLong = false;
                    } else if (value == 0x0D || (value >= 0x20 && value <= 0x7E)) {
                        if (!tooLong) {
                            if (line.size() < MAX_LINE_BYTES) line.write(value);
                            else {
                                tooLong = true;
                                invalidHex.append(" [overflow]");
                            }
                        }
                    } else {
                        invalid = true;
                        if (invalidHex.length() < 160) invalidHex.append(String.format(Locale.US, "%02X ", value));
                    }
                }
            }
            if (running) listener.onDisconnected("HC-05 closed the Bluetooth stream.");
        } catch (IOException e) {
            if (running) listener.onDisconnected("Bluetooth read error: " + e.getMessage());
        }
    }

    private void handleLine(String line) {
        listener.onLog("RX " + line);
        Pending p;
        synchronized (pendingLock) {
            if (discardSnapshotLines > 0) {
                discardSnapshotLines--;
                listener.onLog("Discarded remaining field from an incomplete STATUS snapshot.");
                return;
            }
            p = pending;
            if (p != null) {
                if (!p.ackReceived) {
                    if (line.equals(p.expectedAck)) {
                        p.ackReceived = true;
                        p.ack.countDown();
                        return;
                    }
                    if (line.startsWith("ERR:")) {
                        p.error = line;
                        p.ack.countDown();
                        p.snapshotDone.countDown();
                        listener.onDeviceError(line);
                        return;
                    }
                } else if (p.status && p.index < 5) {
                    if (line.startsWith("ERR:")) {
                        p.error = line;
                        p.snapshotDone.countDown();
                        listener.onDeviceError(line);
                        return;
                    }
                    if (!parseSnapshotField(p.snapshot, p.index, line)) {
                        p.error = "Malformed STATUS snapshot at field " + (p.index + 1) + ": " + line;
                        discardSnapshotLines = 4 - p.index;
                        p.snapshotDone.countDown();
                        listener.onLog("Snapshot rejected; remaining snapshot fields will be discarded.");
                        return;
                    }
                    p.index++;
                    if (p.index == 5) {
                        Snapshot complete = copySnapshot(p.snapshot);
                        listener.onSnapshot(complete);
                        p.snapshotDone.countDown();
                    }
                    return;
                }
            }
        }
        processUnsolicited(line);
    }

    private boolean parseSnapshotField(Snapshot s, int index, String line) {
        switch (index) {
            case 0:
                if ("LAMP:0".equals(line)) { s.lamp = "OFF"; return true; }
                if ("LAMP:1".equals(line)) { s.lamp = "ON"; return true; }
                return false;
            case 1:
                if ("PLUG:0".equals(line)) { s.plug = "OFF"; return true; }
                if ("PLUG:1".equals(line)) { s.plug = "ON"; return true; }
                return false;
            case 2:
                if ("DOOR:OPEN".equals(line) || "DOOR:CLOSED".equals(line)) {
                    s.door = line.substring(5); return true;
                }
                return false;
            case 3:
                if ("TEMP:ERR".equals(line)) { s.temperatureError = true; return true; }
                if (line.startsWith("TEMP:") && TEMP.matcher(line.substring(5)).matches()) {
                    s.temperature = Double.parseDouble(line.substring(5)); return true;
                }
                return false;
            case 4:
                if ("ALARM:0".equals(line)) { s.alarm = false; return true; }
                if ("ALARM:1".equals(line)) { s.alarm = true; return true; }
                return false;
            default: return false;
        }
    }

    private Snapshot copySnapshot(Snapshot a) {
        Snapshot b = new Snapshot();
        b.lamp = a.lamp; b.plug = a.plug; b.door = a.door;
        b.temperature = a.temperature; b.temperatureError = a.temperatureError; b.alarm = a.alarm;
        return b;
    }

    private void processUnsolicited(String line) {
        if (line.startsWith("TEMP:")) {
            String value = line.substring(5);
            if ("ERR".equals(value)) listener.onTemperature(null, true);
            else if (TEMP.matcher(value).matches()) listener.onTemperature(Double.parseDouble(value), false);
            else listener.onLog("Protocol warning: malformed TEMP value.");
        } else if ("DOOR:OPEN".equals(line) || "DOOR:CLOSED".equals(line)) {
            listener.onDoorEvent(line.substring(5));
        } else if ("ALARM:1".equals(line) || "ALARM:0".equals(line)) {
            listener.onAlarm("ALARM:1".equals(line));
        } else if (line.startsWith("ERR:")) {
            listener.onDeviceError(line);
        } else if (line.startsWith("ACK:")) {
            listener.onLog("Unmatched ACK: " + line);
        } else {
            listener.onLog("Unrecognized protocol line: " + line);
        }
    }

    void close() {
        running = false;
        synchronized (pendingLock) {
            if (pending != null) {
                pending.error = "Bluetooth disconnected.";
                pending.ack.countDown();
                pending.snapshotDone.countDown();
                pending = null;
            }
        }
        try { input.close(); } catch (IOException ignored) { }
        try { output.close(); } catch (IOException ignored) { }
        readerExecutor.shutdownNow();
        commandExecutor.shutdownNow();
    }
}
